# Data Subject Request Procedure

To exercise your rights under GDPR, LFPDPPP, or other applicable laws, please email privacy@yourdomain.com with your request. We will respond within the legally required timeframe.

Requests supported:
- Access to your data
- Correction of your data
- Deletion of your data
- Export of your data
- Withdrawal of consent

---

This is a template. Please consult legal counsel for your specific needs.
