# Terms of Service

_Last updated: September 1, 2025_

By using this site, you agree to comply with all applicable laws and regulations, including those of the USA, Mexico, and the EU. You are responsible for maintaining the confidentiality of your account and for all activities that occur under your account.

## User Responsibilities
- Provide accurate information
- Respect intellectual property
- Do not misuse the service

## Data Usage
- See our Privacy Policy for details

## Limitation of Liability
- The service is provided "as is" without warranties

## Contact
For questions, contact: support@yourdomain.com

---

This is a template. Please consult legal counsel for your specific needs.
